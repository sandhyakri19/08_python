# n=0
# while n<10:
#     n+=1
#     if n==6:
#         continue
#     print(n)


""" 2nd type"""
"""
n=0
while n<10:
    n+=1
    if n<5:
        continue
    print(n)
"""

""" 3rd type """
"""
n=0
while n<10:
    n+=1
    if n>5:
        continue
    print(n)
"""

""" 4th type  """
"""
n=0
while n<10:
    n+=1
    if n<=5:
        continue
    print(n)
"""

# if (11>2):
#     pass
# else:
#     print('False')