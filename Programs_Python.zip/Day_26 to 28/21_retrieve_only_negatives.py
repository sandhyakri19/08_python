# n=[5,10,15,20,-4,-3,-1,0,8]
# n.sort()
# for i in n:
#     if(i<0):
#         print(i)