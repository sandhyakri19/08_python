""" with the help of range and for loop """
# n=int(input("Enter any number: "))
# for j in range(1,n+1):
#     print(j)

''' with the help of while loop '''
a=1
while(a<=10):
    print(a)
    a=a+1  # a+=1