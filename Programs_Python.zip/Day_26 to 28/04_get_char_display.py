c=(input("Enter a char:"))
# """we can perform it in 2 ways"""
print("The Entered Character is: "+c[-1])
print("The Entered Character is:",c[-1])

# d=float(c) 
# e=int(d) 
# v=str(e)
# print(v[0]) 