# n=int(input("Enter a Number:"))
# if n%2==0:
#     print(f"{n} is Even Number")
# else:
#     print(f"{n} is Odd Number")

""" Program for one even number then rest of all odd"""
# n=int(input("Enter a Number:"))
# for i in range(2,n,2):
#      print(i)

# n=int(input("Enter a Number:"))
# for b in range(1,n,2): 
#     print(b)


# n=int(input())
# k=int(input())
# while(n<=k):
#     print(n)
#     n+=2