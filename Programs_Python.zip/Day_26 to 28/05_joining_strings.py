s1,s2=input('Enter two Strings:').split(",")
# print(s1+s2)
print(s1,s2,sep="-")