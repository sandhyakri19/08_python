# n=-1
# while(n<20):
#     n+=2
#     if n>8:
#         break
#     print(n)

# n=0
# while(n<10):
#     n+=1
#     if n==4:
#         break
#     print(n)

# n=0
# while(n<20):
#     n+=2
#     if(n==10):
#         break
#     print(n)