n=int(input(" Multiplication of Which Table? : "))
for i in range(1,11):
    print(n,'X',i,'=',n*i)