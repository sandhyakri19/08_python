# name="python"
# for n in name:
#     print(n)

""" In Reverse order """
name="python"
# for n in name[::-1]:
#     print(n)

""" Printing the words alternatively"""
# name="python"
# for n in name[ : : 2 ]:
#     print(n)