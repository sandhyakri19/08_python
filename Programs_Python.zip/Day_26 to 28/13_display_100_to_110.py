# without using any variable
# for i in range(100,111):
#     print(i)

# with the help of a variable
# a=range(100,111)
# for y in a:
#     print(y)

""" with the help of while """
m=int(input("Enter the value of m:"))
n=int(input("Enter the value of n:"))
while(m<=n):
    print(m)
    m+=1