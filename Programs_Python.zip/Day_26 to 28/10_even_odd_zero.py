n=int(input("Enter any Positive Number:"))
if(n==0): print("The user entered {} Number".format(n))
elif(n%2==0): print("The Number {} is Even Number".format(n))
else: print("The number {} is Odd Number".format(n))