for i in range(100,111,2):
    print(i)