""" To find how many elements
are present inside the lists"""

# m1=[5,10,15,20,25,30,35,67,65]
# c=0
# for i in m1:
#     c+=1
# print('No. of Elements present inside the lists is =',c)
# print(len(m1))

""" Sum of the elements inside the lists"""
# import math
# a=[7,8,6]
# print(a[0]+a[1]+a[2])
# print('The Sum of all the lists is',math.fsum(m1))
# print('The Sum of all the lists is',math.fsum(a))
# print('The Sum of all the lists is',math.fsum(m1+a))
# # print(sum(m1))
# print(sum(a))
# print(sum(m1+a))


""" Sum of Numbers   """
# import math
# a,b,c,d=[float(x) for x in input().split()]
# y=a,b,c,d
# print(sum(y))
# print(int(math.fsum(y))) 
# print(math.fsum(y)) 