""" Sum and Average of 3 Numbers """
# a,b,c=[float(x) for x in input("Enter 3 Numbers:").split(',')]
# sum=a+b+c
# avg=sum/3
# print("The Sum is %.2f\nAverage is %.2f" %(sum,avg))

# s=10,20,30
# r=sum(s)
# print(r)
# av=r/3
# print(av)