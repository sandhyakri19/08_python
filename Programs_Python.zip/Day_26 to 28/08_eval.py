k=eval(input("Enter numbers:"))
# print(k,type(k))
print(("Num=%f"%k))