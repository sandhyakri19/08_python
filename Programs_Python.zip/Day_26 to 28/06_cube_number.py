n=float(input("Enter Any Number:"))
print("Cube of the Number is:",n**3)

import math
a=float(input("Enter any Number: "))
print(math.pow(a,3))

v=int(input("Enter the ending value: "))
for i in range(1,v+1):
    print(i**3)