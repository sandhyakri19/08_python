# """
# r=float(input("Enter the Radius:"))
# PI=22/7
# Area=PI*r**2
# print("The Area of the Circle is %.2f" %Area)

# """

""" Another Method """
"""
import math
r=float(input("Enter the Radius:"))
Area=math.pi*r**2
print("The Area of the Circle is:%.2f" %Area)
"""

# import math
# print(math.pi)
