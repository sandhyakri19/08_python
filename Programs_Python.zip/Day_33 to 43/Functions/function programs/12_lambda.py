# a lambda function to calculate square value
f = lambda x: x**2 #write lambda function
value = f(5) #call, lambda function
print('square of 5 =', value) #display result