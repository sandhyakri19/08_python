# def n(lm):
#     lm.pop() 
#     print(lm)
    
# lm=[1,2,3]
# n(lm)