# Addition of two numbers using functions
def s(a,b):
    c=a+b
    d=a+b
    print('sum is',c)
    print('sum is',d)

s(10,20)
s(10.5,2.3)