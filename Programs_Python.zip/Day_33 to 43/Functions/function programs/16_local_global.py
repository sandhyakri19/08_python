# Example on Local and Global Variable

# a=50 # Global Variable
# def number():
#     b=30 # Local Variable
#     a=40
#     print(a)
#     print('Local Variable(b):',b)
#     print('Global var a:',a)
# print('Global var a:',a)
# number()
# print('Global var a:',a)

c=200
def fn():
    global c
    c=20
    print(c)
print(c)    
fn()
print(c)