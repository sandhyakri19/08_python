def eo(num):
    if num%2==0:
        print(num, "is even")
    else:
        print(num,"is odd")
n=int(input())
eo(n)
eo(12)
eo(13)