x=int(input("Enter your number greater than 18: "))
assert x>=18, "Age is less than 18"
print('You are Eligible to Vote',x)