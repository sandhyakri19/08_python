# a lambda function to calculate sum of two numbers
f = lambda x,y,z: x+y+z #write lambda function
s = lambda x,y,z: x*y*z #write lambda function
r = f(3,10,5) #call lambda function
z= s(2,3,5)
print('Sum =',r)# display r
print('Mul =',z)# display z