# Example prg for Default Argument

def info(name="HEY",age=45):
    print('Name :',name)
    print('Age :',age)
info()
info('Py')
info('rav',25)
info(name='gopal')
info(age=26)