# a lambda function that returns bigger number
m = lambda x, y: x if x<y else y #write lambda function
x,y= [int(n) for n in input("enter two numbers: ").split()]
print(m(x,y))

# a= [int(n) for n in input("enter numbers: ").split()]
# print('Bigger number is:', max(a))
# print('Smaller number is:', min(a))

# a=20,39,50
# print(max(a))
# print(min(a))