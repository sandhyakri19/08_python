# def num_sort(lis):
#     lis.sort()
#     for i in lis: print(i,end=" ")
# print("Enter Numbers: ")
# v=[int(x) for x in input().split()]
# num_sort(v)

"""2nd way"""
# list=[int(x) for x in input().split()]
# list.sort(reverse=True)
# print(*list)