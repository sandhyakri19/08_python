def sum(a,b):
    c=a+b
    return c

x=sum(10,20)
print('sum is',x)
y=sum(10.5,2.3)
print("sum is: ",y)