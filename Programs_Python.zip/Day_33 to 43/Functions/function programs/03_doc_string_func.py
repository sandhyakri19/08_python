def gm(): 
  '''Author: Python 2PM
The time is now 2:10pm
We are doing functions topic'''
# print(gm.__doc__)