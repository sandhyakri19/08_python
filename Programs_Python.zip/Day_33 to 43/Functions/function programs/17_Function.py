# def num(name1='3.10.5',Hello="Python"):   # function declaration
#     print("Function Program basics",Hello,name1) 
# num() ;'''num should be exactly at left , it is for calling the function'''
# num(22,"Py")
# num("Josh","Python")
# num('10Am','Function Topic')
# num(11)
# num(name1=11)
# num(Hello=22)
"""at the time of calling a function and passing a values into it
then the values passed during the calling function will be taken
into consideration. it is nothing but the values have been updated."""


# def j(uk):
#     print("Hi")
# j(1)