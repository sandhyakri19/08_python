import fivepmbatch as fv
fv.day()
fv.sat()