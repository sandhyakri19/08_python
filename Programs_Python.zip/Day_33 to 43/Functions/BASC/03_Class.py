class number:
    x=2022
    y=365
# print(number.x)
# print(number.y)
b=number()
print(b.x)
print(b.y)