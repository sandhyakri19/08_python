def day():
    print('class from mon to fri')

def sat():
    print('even taken on Saturday')