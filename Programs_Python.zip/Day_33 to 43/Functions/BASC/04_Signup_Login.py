usr=input('Enter Username: ')
pwd=input('Enter Password: ')
print('Account Created')
name=input('Enter Username: ')
psw=input('Enter Password: ')
if(usr==name and psw==pwd):
    print('You have Logged in Succesfully!')
else:
    print('Invalid Details')