a1=[
    [1,2,3],
    [4,5,6],
    [7,8,9,10]
]
# print(a1)
# print(a1[0])
# print(a1[0][0])
for n in a1:
    for m in n:
        print(m)