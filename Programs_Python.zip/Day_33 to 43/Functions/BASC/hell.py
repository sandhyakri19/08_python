def hd():
    print('Welcome to Python Space')

def students():
    print("We are doing Python Programming")