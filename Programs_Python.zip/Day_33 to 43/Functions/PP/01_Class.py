class josh():
    course1="Core Python"
    course2="Adv Python Programming"
print(josh.course1)
print(josh.course2)
print(josh.course1,josh.course2)
p=josh()
print(p.course1)
print(p.course2)
print(p.course1+" "+p.course2)