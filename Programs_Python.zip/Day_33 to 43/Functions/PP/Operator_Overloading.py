# a="hello" ; b="python"
# print(a+b)
# c=5 ; d=6
# print(c+d)
# e=[1,2,3] ; f=[4,5,6]
# print(e+f)
# print(e[:]+f[:])