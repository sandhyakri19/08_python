# import os
# print(os.getcwd())

import os
# os.mkdir('4pm batch')
# os.rmdir('4pm batch')
# os.remove('josh940Am.txt')
# print(os.path.exists('Josh2pm.txt'))
# print(os.path.exists('Josh.txt'))
# print(os.path.exists('2pm BaTch'))