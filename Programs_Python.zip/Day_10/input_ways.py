# a=input('Enter your Name:')
# print("My Name is",a)
# print("My Name is",a,sep="-")
# print("My Name is",int(a))  
# print("My Name is",float(a)) 
# print("My Name is"+' '+str(a))
# print("My Name is"+' '+a)

# a=int(input('Enter your Phone Number:'))
# print("Your Phone Number is",a)
# print("Your Phone Number is",a,sep=" ")
# print("Your Phone Number is",int(a))
# print("Your Phone Number is",float(a))
# print("Your Phone Number is"+' '+str(a))

# a=float(input('Enter your BMI:'))
# print("Your BMI is",a)
# print("Your BMI is",a,sep=" ")
# print("Your BMI is",int(a))
# print("Your BMI is",float(a))
# print("Your BMI is"+' '+str(a))

# name=input("Enter Your Name:")
# age=int(input("Enter Your Age:"))
# per=float(input("Enter your Graduation Percentage:"))

# print(name,age,per)

# print(age,name,per)

# print(name,age,name)

# name=input("Enter Your Name:")
# age=int(input("Enter Your Age:"))
# per=float(input("Enter your Graduation Percentage:"))

# print("Your Name is",name,"and age is",age,\
# "Graduation percentage is",per)

# print("Your Name is"+' '+name,"and age is",age, \
# "Graduation percentage is",str(per)+'%')

# print("Your Name is %s and age is %d. \
# Graduation percentage is %.2f"%(name,age,per))

# print("Your Name is {} and age is {}. \
# Graduation percentage is {}".format(name,age,per))

# print("Your Name is {1} and age is {0}. \
#  Graduation percentage is {2}".format(age,name,per))

# print(f"Your Name is {name} and age is {age}.\
# Graduation percentage is {per}")
