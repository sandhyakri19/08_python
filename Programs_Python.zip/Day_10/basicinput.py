# a=input()
# print(a,type(a))
# print("The value of a is "+a)

# b=input()
# print(b,type(b))
# print("The value of b is "+b)

# c=int(input('Enter your Phone Number:'))
# print(c,type(c))
# print("The value of c is",c)

# d=float(input('Enter your height:'))
# print(d,type(d))
# print("The value of d is",d)

# e=str(input('Enter your name:'))
# print(e,type(e))
# print("Your name is:",e)