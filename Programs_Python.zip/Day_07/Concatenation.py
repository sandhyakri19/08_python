# a="Python" ; b= "Programming"
# print(a+b)
# print(a,b)
# print(a+' '+b)
# print(a+chr(32)+b) 

# a="5"; b="7"; c=8
# print(a+b)
# print(a,b+str(c))
# print(a+" "+b+str(c))