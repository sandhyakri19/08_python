# a=3
# print("The value of a is",a)
# print("The value of a is ",a)

# b=""
# print(b,type(b))

# c=""
# print(c.isspace())

# d=5
# print(type(d))
# print(int(d))
# print(float(d))
# print(str(d))

# b=7.8
# print(type(b))
# print(float(b))
# print(int(b))
# print(str(b))

# d='DELL'
# print("One of the Laptop Brand is",d)
# print(''+d)
# print(' '+d)
# print("One of the Laptop Brand is"+d)
# print("One of the Laptop Brand is"+' '+d)

# d="12"
# print(d,type(d))
# print(int(d))
# print(float(d))


# print(int(5.6))
# print(float(3))
# print(int("python"))
# print(float("program"))

# e='67.45'
# print(e,type(e))
# g=float(e) 
# print(g)
# print(int(e))
# print(int(g))  