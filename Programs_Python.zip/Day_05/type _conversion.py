a=4
print(type(a))
print(float(a))
print(str(a))

b=6.8
print(type(b))
print(int(b))
print(str(b))