# a=5
# print(a,type((a)))
# print("The value of a is",a) 
# print("The value of a is %d"%a) 
# print("The value of a is %f"%a) 
# print("The value of a is %s"%a) 

# b=4.7
# print(b,type(b)) 
# print("The value of b is",b) 
# print("The value of b is %f"%b)
# print("The value of b is %d"%b)
# print("The value of b is %s"%b)

# c=2.47
# print("The value of c is %.1f" %c)
# print("The value of c is %s" %c)

# d=2
# print("The value of d is %f"%d)

# g=1.3+4.5
# print("%f"%g)   
# print("%.1f"%g)   
# print("%2f"%g)   
# print("%.3f"%g)   
# print("%7f"%g)   
# print("%8f"%g)   
# print("%9f"%g)   
# print("%10f"%g)   
# print("%11f"%g)   

# h=0.2+0.7 
# y=0.2+0.4  
# k=0.2+0.1
# print(h)
# print(y)
# print(k)
# print("The value of h is %.1f"%h)
# print("The value of y is %.1f"%y)
# print("The value of k is %.1f"%k)


# j="josh"
# print("%d" %j)
# print("%f" %j)
# print("The name of the institute is %s"%j)
# print("The name of the institute is%s"%j)
# print("The name of the institute is",j)