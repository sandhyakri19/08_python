""" Converting int to float and string"""
# a=7
# print(a,type(a)) 
# b=float(a)
# print(b,type(b)) 
# c=str(a)
# print(c,type(c)) 

# x=7
# print("The value of x is",x)
# print("The value of x is%d"%x)
# print("The value of x is"+' '+str(x))

""" convert float to int and str """
# q=7.5
# print(q,type(q))
# w=int(q)
# print(w,type(w))
# e=str(q)
# print(e,type(e))

"""" converting str to int and float """

# t="ameerpet"
# print(t,type(t))
# y=int(t)
# z=float(t)

# p='123.9'
# print(p,type(p))
# a=int(p) 
# s=float(p)
# print(s,type(s))
# v=int(s)
# print(v,type(v))

# a=5+4
# print(a,type(a))

# b=0.1+0.2
# print(b)
# print('%f'%b,type(b))

# c="Python Programming"
# print(c,type(c))

# y='Josh'; j='hey'
# print(y,type(y))
# print("%s" %(j))

# k=57
# print("%c"%k)
# e='Y'
# print("%c"%e)

# print(chr(0)+"python")
# print(chr(32)+"python")

# a=5
# b=float(a)
# print(b)

# c=6.7
# d=int(c)
# print(d)

# e='josh'
# f=int(e)
# g=float(e)

# h='56'
# i=int(h)
# print(i)
# j=float(h)
# print(j)


# h='56.9'
# # i=int(h)
# j=float(h)
# print(j)
# k=int(j)
# print(k)

# p=6;r=4.5
# s=p+r
# print(s,type(s))