# n1=[10,20,30,40,50,60]
# n2=[1,2,3,4,5]
# print(n1+n2)
# rp=list(zip(n1,n2))
# print(rp)

# n1=[10,20,30,40,50,60]
# n2=[1,2,3,4,5]
# for x,y in zip(n1,n2):
#     print(x,y)

# n1=[10,20,30,40,50]
# n2=[1,2,3,4,5]
# for x,y in zip(n1,n2):
#     print(x+y,x-y)

# a=range(10,15)
# b=range(1,5)
# for x,y in zip(a,b):print(x+y)