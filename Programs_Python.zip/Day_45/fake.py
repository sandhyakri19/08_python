# from faker import Faker
# fakedata=Faker()
# print(fakedata.name())
# print(fakedata.email())
# print(fakedata.password())
# print(fakedata.address())

# from faker import Faker
# from openpyxl import Workbook
# wb=Workbook()
# ws=wb.active
# fake_data=Faker()
# for i in range(1,11):
#     ws.cell(row=i,column=1).value=fake_data.name()
# wb.save("4pmPython.xlsx")