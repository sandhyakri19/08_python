a=5 ; b=7
print(id(a))
print(id(b))