a=""
print(bool(a))
b=1
print(bool(b))
c=0
print(bool(c))
d="hello"
print(bool(d))
e=" "
print(bool(e))