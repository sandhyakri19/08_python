import math
# print(math.ceil(0.1)) 
# print(math.ceil(2.4))
# print(math.ceil(7.3))
# print(math.ceil(-0.3)) 
# print(math.ceil(-4.3)) 
# print(math.ceil(22.6))
# print(math.ceil(14.1)) 
# print(math.exp(1))
# print(math.exp(3))
# print(math.factorial(0)) 
# print(math.factorial(1)) 
# print(math.factorial(2)) 
# print(math.factorial(3)) 
# print(math.factorial(4)) 
# print(math.factorial(5)) 
# print(math.floor(23.4))
# print(math.floor(23.5))
# print(math.floor(23.6))
# print(math.floor(-23.6))
# print(math.floor(-19.0))
# print(math.floor(-19.1))
# print(math.ceil(75.0))
# print(math.ceil(75.3))
# print(math.floor(75.3))
# print(math.ceil(75.5))

''' when used math module we get answer
    in terms of float'''
# a=math.pow(3,3)
# b=3**3
# print(a,type(a))
# print(b,type(b))
# print(math.pi)
# print(math.pi*2)
# print(math.pi*3**2)
# print(math.sqrt(4))
# print(math.sqrt(6.7))
# print(math.sqrt(24))
# print(math.sqrt(25))
# c=2   # 1 to 3 will give 1 if used isqrt
# d=6   # 4 to 8 will give 2 if used isqrt
# e=14   # 9 to 15 will give 3 if used isqrt
# f=0   # 0 will give 0 if used isqrt
# print(math.isqrt(c))
# print(math.isqrt(d))
# print(math.isqrt(e))
# print(math.isqrt(f))


# n=[1,2,3,4,5]
# print(sum(n))
# print(math.fsum(n))
# print(math.prod(n))
# print(int(math.fsum(n)))
# g=17%3
# print(g)
# print(math.fmod(17,3))
# v=-4
# print(abs(v))
# a=abs(int(input()))
# print('The person age is',a)

# print(math.fabs(-8))
# print(math.cos(45))
# print(math.sin(45))
# print(math.tan(45))
# print(math.trunc(4.55))
# print(math.trunc(-6.55))
# print(int(-6.55))
# print(math.gcd(18,11))
# print(math.gcd(18,13))
# print(math.gcd(18,17))
# print(math.gcd(18,19))
# print(math.gcd(18,23))
# print(math.gcd(18,29))
# print(math.gcd(24,32))
# print(math.gcd(28,64))
# print(math.gcd(52,86))
# print(math.gcd(6,16))
# print(math.lcm(6,16))
# print(math.lcm(8,14))
# print(math.lcm(6,18))

# import math
# print(dir(math))