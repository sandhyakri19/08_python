import numpy as np
# a = np.array([[10,20,30],
#               [40,50,60]])
# b = np.array([[1,2,3],
#               [4,5,6]])
# c = a + b
# d = a * b
# e = a - b
# f = 3 * a
# print(c)
# print(d)
# print(e)
# print(f)

# g = np.eye(2)
# print(g) 
# h = np.eye(3,dtype=int)
# print(h) 

# h = np.array([x for x in range(9)])
# i = h.reshape((3,3))
# print(i)

# j = np.array([[2.5, 3.8, 1.5],
#               [4.7, 2.9, 1.56]])
# k = j.astype('int')
# print(k)

# l = np.array([[1, 0, 0],
#               [1, 1, 1],
#               [0, 0, 0]])
# m = l.astype('bool')
# print(m)

# n = np.array([[1,2,3],
#                [4,5,6]])
# o = np.array([[7,8,9],
#                [10,11,12]])
# p = np.hstack((n, o))
# print(p)

# q = np.array([[1,2],
#                [3,4],
#                [5,6]])
# r = np.array([[7,8],
#                [9,10],
#                [10,11]])
# s = np.vstack((q, r))
# print(s)

# t = [x for x in range(0, 101, 2)]
# u = np.array(t)
# print(u)

# v = np.arange(0, 101, 2)
# print(v)

# w = np.array([1,2,3,4,5])
# x = np.array([1,3,2,4,5])
# print(np.where(w == x))

# z = np.full((3, 3), 8)
# print(z)

# a = np.array([[1,2,3],
#               [4,5,6],
#               [7,8,9]])

# b = np.array([[2,3,4],
#               [5,6,7],
#               [8,9,10]])
# c = a@b
# d = np.matmul(a, b)
# print(c)
# print(d)

# e = np.array([[1,2,3],
#               [4,5,6],
#               [7,8,9]])
# f = e.T
# print(f)

# print((dir(np)))