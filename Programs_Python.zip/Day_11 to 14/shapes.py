# Print the Following Pattern
#    +----------+

# print("+----------+")
# the above is the one way

# The another way is

# print("+"+ 10 * "-"+ "+")

# print the following pattern
#    *----------*

# print("*"+ 10 * "-"+ "*")

# print the following pattern
#    +----------+
#    |          |
#    |          |
#    |          |
#    |          |
#    |          |
#    +----------+

# print("+"+10*"-"+"+")
# print(("|"+10*" "+"|\n")*5,end="")
# print("+"+10*"-"+"+")
