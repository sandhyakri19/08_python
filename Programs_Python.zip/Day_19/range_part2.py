# n=int(input("Enter any Integer Number:"))
# for i in range(n):
#     print(i)
#     print(i)
#     print(i)
#     print("The Loop has been executed.")
# print("Done")


# n=int(input("Enter any Integer Number:"))
# for i in range(1,n):
#     print(i)

# n=int(input("Enter any Integer Number:"))
# for i in range(25,n):
#     print(i,end=" ")
 
# n=int(input("Enter any Integer Number:"))
# for i in range(2,n,2):
#     print(i)


# b=int(input("Enter Any Integer Number:"))
# if(b%2==0):
#     print(f"{b} Even Number")
# else:
#     print(f"{b} Odd Number")


# for i in range(1,5):
#     print(i*i)

# a=5
# print(a) # 5
# a+=2   
# print(a) # 7
# a-=1  
# print(a) # 7-1=6

# n=int(input("Enter the value of n:"))
# while(n<10):
#     print("hello",str(n))
#     n+=1