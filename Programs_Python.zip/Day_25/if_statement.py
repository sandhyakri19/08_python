# a=int(input("Enter the Value of a:"))
# b=int(input("Enter the Value of b:"))
# a,b=[int(x) for x in input().split()]
# print(a,b)

# a=int(input("Enter the Value of a:"))
# if( a==5):
#  print("Yes Equal")

# a,b=[int(x) for x in input().split()]
# if(a>b):
#     print(f"{a}>{b} is {a>b}")
# else:
#     print(f"{a}<{b} is {a<b}")

# a,b=[int(x) for x in input().split()]
# if(a>b):print("a is greater than b")
# if(a<b):print("a is less than b")
# if(a<=b):print("a is less than  or equal to b")
# if(a>=b):print("a is greater than or equal to b")
# if(a!=b):print("a is not equal to b")
# if(a==b):print("a is equal to or is same as b")

# a,b=[int(x) for x in input().split()]
# if(a>b):print("a is greater than b")
# elif(a<b):print("a is less than b")
# elif(a<=b):print("a is less than  or equal to b")
# elif(a>=b):print("a is greater than or equal to b")
# elif(a!=b):print("a is not equal to b")
# elif(a==b):print("a is equal to or is same as b")