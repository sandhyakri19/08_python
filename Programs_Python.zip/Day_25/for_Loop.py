# a=1,2,3,4,5
# print(*a)

# for josh in a:
#     print(josh,end=" ")

# for i in range(5):
#     print(i)

# n=int(input("Enter the value of n:"))
# for i in range(1,n+1):
#     print(i,end="\n")

# for i in range(1,30,2):
#     print(i,end=' ')

# for i in range(2,30,2):
#     print(i,end=' ')

# for i in range(10,0,-1):
#     print(i)

# for i in range(10,-1,-1):
#     print(i)

# n=[1,4.5,'python']
# for i in n[::-1]:
#     print(i)

# v='programming'
# for e in v[::2]:
#     print(e)