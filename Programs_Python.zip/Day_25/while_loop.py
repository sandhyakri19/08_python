# i=int(input('Enter any Start Value:'))
# k=int(input('Enter the End Value:'))
# while(i<=k):
#     print(i)
#     i+=1

# i=int(input('Enter any Start Value:'))
# k=int(input('Enter the End Value:'))
# while(i>=k):
#     print(i)
#     i-=1

# i=1
# while(i<=10):
#     print('Hi',i)
#     i+=1