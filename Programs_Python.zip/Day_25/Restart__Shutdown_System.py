# For restarting the system
import os
os.system('shutdown /r /t 0')


# For Shutdown
# import os
# os.system('shutdown /s /t 1')