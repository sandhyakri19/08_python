# a=int(input("Enter the value of a:"))
# b=int(input("Enter the value of b:"))
# if(a<b):
#     print(f"{a} < {b} is True")


# a=int(input("Enter the value of a:"))
# b=int(input("Enter the value of b:"))
# if(a<b):
#     print(f"{a} < {b} is True")
#     print("Hey Python")
#     print("Its done.")

# a=int(input("Enter the value of a:"))
# b=int(input("Enter the value of b:"))
# if(a<b):
#     print(f"{a} < {b} is True")
#     print("Hey Python")
#     print("Its done.")
# print("Try Next Time")

# a=int(input("Enter the value of a:"))
# b=int(input("Enter the value of b:"))
# if(a<b):
#     print(f"{a} < {b} is True")
# if(a<=b):
#     print(f"{a} < = {b} is True")
# if(a>b):
#     print(f"{a} > {b} is True")
# if(a>=b):
#     print(f"{a} > ={b} is True")
# if(a==b):
#     print(f"{a} == {b} is True")


# a=int(input("Enter the value of a:"))
# b=int(input("Enter the value of b:"))
# if(a<b):
#     print(f"{a} is less than {b}")
# else:
#     print(f"{a} is greater than {b}")


# a=int(input("Enter the value of a:"))
# b=int(input("Enter the value of b:"))
# if(a<b):print(f"{a} is less than {b}")
# elif(a>b):print(f"{a} is greater than {b}")
# elif(a<=b):print(f"{a} is less than or equal to {b}")
# elif(a>=b):print(f"{a} is greater than or equal to {b}")
# elif(a==b):print(f"{a} is same as {b}")
# elif(a!=b):print(f"{a} is not equal to {b}")
# else:print("Try again!") # optional

# n=int(input("Enter any Integer Value:"))
# if(n%2==0):
#     print(f"{n} is an Even Number")
# else:
#     print(f"{n} is an Odd Number")