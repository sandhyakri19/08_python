'''print types in python'''

# print("Hello World") 

# print('Hello World')

# print("Program\
# on 10th Dec")

# print('Hello' 'Python')

# print("Hello" , 'Python')

# print()

# print('')

# print("")

# print('''Hello
#     Welcome to
#     Python Programming''')


# print('''Hello Welcome to 
# Python Programming''')

# print('''Hello Welcome to \
# Python Programming''')

# print("Python"
# "2nd floor")

# print("Python",
# "2nd floor")

# print("Josh"), print("Innovations")

# print("Josh"); print("Innovations")


# print("Hello", end="")
# print("python")  

# print("Hello", end=" ")
# print("python") 

# print("Hello", end=".")
# print("python") 

# print("Hello", end=". ")
# print("python",end=" ") 
# print("hi")


# print("Realme" , "GT",sep="") 
# print("Realme" , "GT",sep=" ") 
# print("Realme" , "GT",sep=".") 
# print("Realme"   "GT",sep="-") 

# print("core", "python",end="" "hello") 
# print("core", "python",end=" " "hello") 
# print("core", "python",end="-" '3') 


''' Note: The Above Output is
core pythonhellocore python hellocore python-3
'''
# print("core", "python",sep="-" "hello") 
# print("core", "python",end=" " "hello") 
# print("core", "python",end="-" '3') 

# print("core", "python",sep=" ",end="hello")
# print("core", "python",sep="-",end=" hello") 
# print("core", "python",sep=" ",end='-3')

# print("core", "python",end="hello",sep=" ") 
# print("core", "python",end=" " "hello",sep=" ") 
# print("core", "python",end='-3',sep=" ") 

# print("Hello "*10)
# print("Hello\n"*10,end="")