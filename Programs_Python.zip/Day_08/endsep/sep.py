# print('hello'   ,  'world')
# print('hello' +' '+   'world')
# print('hello'+chr(32)+'world')

# print('python'+"-"+'program'+'-'+'world')

# print('hello', 'world',sep="*")

# print('p','y','t','h','o','n',sep='@')