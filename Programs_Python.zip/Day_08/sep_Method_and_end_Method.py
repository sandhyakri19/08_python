# print("Hello" , "World")
# print("Hello"  "World")  
# print("Hello"+'-'+"World") 
# print("Hello"  "World",'Core', 'Python',sep="")
# print("Hello"  "World",'Core', 'Python',sep="-")
# print("Hello" , "World",'Core', 'Python',sep="-",)
# print("Hello" , "World",'Core', 'Python',sep="-" "ok")
# print("Hello" , "World",'Core', 'Python',sep="-"+ "ok")
# print("Hello" , "World",'Core', 'Python',sep="-" ' ' "ok")


"""  end method  """

# print("Hello" , "Python",end=".")
# print("Hello" , "Python",end="-")
# print("New Version is 3.10.4")
# print("ok fine")

# print("Hello" , "Python",end="-")
# print("New Version is 3.10.4",end=" ")
# print("ok fine")


""" Combinatio of end and sep method  """

# print("TATA" , "IPL" , end="." , sep='')
# print("TATA" , "IPL" , end="." , sep='-')
# print("core" , "programming" , "python",sep="@", end="#")

# print("Python\n" *5,end="") 

# print("hello" , "world", sep=" 123 ")


# print('HD\n' * 4,end='')