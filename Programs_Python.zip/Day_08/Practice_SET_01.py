# print("Hello",end=' '"W")
# print("Hello",end='-'"W")
# print("Hello",end=','"W")

# print("Hello",end=' '"W")
# print("\nHello",end='-'"W")
# print("\nHello",end=','"W")

# print("Hello",end=''"Welcome to Josh innovations\n")

# print("Python Programming",end=",")
# print("From Josh Innovations",end=".")
# print("Course: Core Python Programming")

# print("Hello IPL on 26th MARCH","2 Days to go",sep='-')
# print("Hello",sep=".""Josh Innovations")
# print("Core","Python","Programming",sep="*")

# print("Ameerpet Metro Station",end=".")
# print("Near SAP Street Lane",end="\n")
# print("Josh","Innovations",end='.',sep="-")