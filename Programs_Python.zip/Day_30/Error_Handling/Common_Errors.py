# print(3/0) # ZeroDivisionError
# print(hh) # NameError
# a="hello"
# print(int(a)) # ValueError
# b=4.5
# print(b+"Hello") # TypeError