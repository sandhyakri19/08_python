# y=b"python"
# print(y,type(y))
# print(list(y))
# print(tuple(y))
# print(set(y))

# y=b"python"
# for i in y:
#     print(i)

# print(ord('Y'))
# print(chr(80))


# y=b"python"
# print(type(y))
# y[0]=90 # no modifications

# v=b'[1,2,3]'
# print(list(v))

# print(ord('['))
# print(ord(','))
# print(chr(80))

# m=bytearray(b"python")
# print(m,type(m))
# print(m[0])
# m[0]=80
# print(m)