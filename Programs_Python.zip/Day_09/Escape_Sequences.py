# print('hello\nworld')

# print('hello pyth\'on')

# print("hello py\"thon")

# print('C:\\Users\Josh HD\Desktop\py1030')

# print('F:\Uatch_9_15_AM') # Error

# print('C:\\Users\\JOSH_HD')

# print("C:\\Users\\JOSH\\Downloads")

# print('\u0001') 
# print('\u0002') 
# print('\u0003')
# print('\u0004')
# print('\u0005')
# print('\u0006')
# print('\u0007')
# print('\u0008')
# print('\u0009')
# print('\U0001f601')
# print('\U0001f602')
# print('\U0001f603')
# print('\U0001f604')
# print('\U0001f605')

# import emoji
# print(emoji.emojize(":grinning_face_with_big_eyes:"))
# print(emoji.emojize(":winking_face_with_tongue:"))
# print(emoji.emojize(":zipper-mouth_face:"))
# print(emoji.demojize("😞"))
# print(emoji.demojize("😎"))
# print(emoji.demojize("🥳"))
# print(emoji.demojize("🥺"))
'''
we can get emojis from this website: https://getemoji.com/
'''

# print('https://www.pythonanywhere.com/batteries_included/')
# print("C:\\Users\\JOSH\\Desktop\\915Am")

# print("hello \bworld")
# print("hello\bworld")
# print('hey\\bunny')

# print("hello\tworld")
# print("hello   world")
# print("\thelloworld")
# print("hello\t" "world")
# print("hello   world")


# print("py\ron") 
# print("pyth\ron") 
# print("pythpy\ron")  
# print("hello\rpy ")

# print("My Name is \r Allu Arjun")

# print("hello\ankith")
# print("hello\aankith")
# print("hello\\ankith")
# print("hello\bnkith") 
# print("hello\cnkith")
# print("hello\dnkith")
# print("hello\enkith")
# print("hello\fun")
# print("hello\gnkith")
# print("hello\hnkith")
# print("hello\inkith")
# print("hello\jnkith")
# print("hello\knkith")
# print("hello\lnkith")
# print("hello\mnkith")
# print("hello\nnkith")
# print("hello\onkith")
# print("hello\pnkith")
# print("hello\qnkith")
# print("hello\rnkinth")
# print("hello\snkith")
# print("\thellonkith")
# print("hello\tnkith")
# print("hello \tnkith") 
# print('hello   nkith')
# print("hello  \tnkith")
# print("hello\t nkith")
# print('hello    nkith')
# print("hello\unkith")
# print("hello\vnkith")
# print("hello\wnkith")
# print("hello\xavier")
# print("hello\ynkith")
# print("hello\znkith")

# print("Hello\Umberalla")
# print("Hello\Nikil")