from playsound import playsound
playsound('house.mp3')