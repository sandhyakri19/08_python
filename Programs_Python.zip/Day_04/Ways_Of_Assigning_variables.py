'''1st way of assigning values and printing them'''
# a=5
# A=7
# _4=6
# a_b=8
# c_d_=9
# Abc=10
# print(a)
# print(A)
# print(_4)
# print(a_b)
# print(c_d_)
# print(Abc)

"""2nd way of assigning values and printing them"""
a=5
A=7
_4=6
a_b=8
c_d_=9
Abc=10
print(a);print(A);print(_4);print(a_b);print(c_d_);print(Abc)
# print(a),print(A),print(_4),print(a_b),print(c_d_),print(Abc)

'''3rd way of assigning values and printing them'''
# a=5;A=7;_4=6;a_b=8;c_d_=9;Abc=10
# print(a)
# print(A)
# print(_4)
# print(a_b)
# print(c_d_)
# print(Abc)

'''4th way of assigning values and printing them'''
# a,A,_4,a_b,c_d_=5,7,6,8,9
# print(a)
# print(A)
# print(_4)
# print(a_b)
# print(c_d_)
# print(Abc)

'''5th way of assigning values and printing them'''
# a=e=i=o=u=5
# print(a)
# print(e)
# print(i)
# print(o)
# print(u)

# print(a,e,i,o,u)